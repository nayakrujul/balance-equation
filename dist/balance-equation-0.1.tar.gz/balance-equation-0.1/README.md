# balance-equation
Balance a chemical reaction equation using brute force.
